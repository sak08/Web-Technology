
	<form name="login" action="loguser.php" method="post">
		User Name:<input type="text" name="un" /><br/>
		Password:<input type="password" name="pw"/><br/>
		<input type="submit" name="submit" />
	</form>
<?php
if( isset ($_GET['invalid']) && $_GET['invalid']== 1){
	echo "wrong username or password";
}
if( isset ($_GET['logout']) && $_GET['logout']== true){
	echo "logout successful";
}
?>